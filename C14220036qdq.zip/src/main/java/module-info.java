module com.example.c14220036qdq {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.example.c14220036qdq to javafx.fxml;
    exports com.example.c14220036qdq;
}